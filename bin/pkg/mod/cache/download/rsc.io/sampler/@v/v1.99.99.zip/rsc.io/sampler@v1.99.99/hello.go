// Copyright 2018 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Translations by Google Translate.

package sampler

var hello = newText(`

English: en: 99 bottles of beer on the wall, 99 bottles of beer, ...

`)
